import Controllers from './Controllers'
const Http = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Http