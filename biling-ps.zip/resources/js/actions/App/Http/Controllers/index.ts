import Api from './Api'
import EspDeviceController from './EspDeviceController'
import PromoController from './PromoController'
import HistoriController from './HistoriController'
import Settings from './Settings'
import Auth from './Auth'
const Controllers = {
    Api: Object.assign(Api, Api),
EspDeviceController: Object.assign(EspDeviceController, EspDeviceController),
PromoController: Object.assign(PromoController, PromoController),
HistoriController: Object.assign(HistoriController, HistoriController),
Settings: Object.assign(Settings, Settings),
Auth: Object.assign(Auth, Auth),
}

export default Controllers