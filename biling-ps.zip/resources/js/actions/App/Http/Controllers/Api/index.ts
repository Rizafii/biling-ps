import EspController from './EspController'
import BillingController from './BillingController'
const Api = {
    EspController: Object.assign(EspController, EspController),
BillingController: Object.assign(BillingController, BillingController),
}

export default Api