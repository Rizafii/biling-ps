import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\BillingController::start
 * @see app/Http/Controllers/Api/BillingController.php:18
 * @route '/api/billing/start'
 */
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/billing/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\BillingController::start
 * @see app/Http/Controllers/Api/BillingController.php:18
 * @route '/api/billing/start'
 */
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BillingController::start
 * @see app/Http/Controllers/Api/BillingController.php:18
 * @route '/api/billing/start'
 */
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\BillingController::start
 * @see app/Http/Controllers/Api/BillingController.php:18
 * @route '/api/billing/start'
 */
    const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\BillingController::start
 * @see app/Http/Controllers/Api/BillingController.php:18
 * @route '/api/billing/start'
 */
        startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Api\BillingController::stop
 * @see app/Http/Controllers/Api/BillingController.php:104
 * @route '/api/billing/stop'
 */
export const stop = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/api/billing/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\BillingController::stop
 * @see app/Http/Controllers/Api/BillingController.php:104
 * @route '/api/billing/stop'
 */
stop.url = (options?: RouteQueryOptions) => {
    return stop.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BillingController::stop
 * @see app/Http/Controllers/Api/BillingController.php:104
 * @route '/api/billing/stop'
 */
stop.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\BillingController::stop
 * @see app/Http/Controllers/Api/BillingController.php:104
 * @route '/api/billing/stop'
 */
    const stopForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: stop.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\BillingController::stop
 * @see app/Http/Controllers/Api/BillingController.php:104
 * @route '/api/billing/stop'
 */
        stopForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: stop.url(options),
            method: 'post',
        })
    
    stop.form = stopForm
/**
* @see \App\Http\Controllers\Api\BillingController::getActiveBilling
 * @see app/Http/Controllers/Api/BillingController.php:185
 * @route '/api/billing/active'
 */
export const getActiveBilling = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getActiveBilling.url(options),
    method: 'get',
})

getActiveBilling.definition = {
    methods: ["get","head"],
    url: '/api/billing/active',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\BillingController::getActiveBilling
 * @see app/Http/Controllers/Api/BillingController.php:185
 * @route '/api/billing/active'
 */
getActiveBilling.url = (options?: RouteQueryOptions) => {
    return getActiveBilling.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BillingController::getActiveBilling
 * @see app/Http/Controllers/Api/BillingController.php:185
 * @route '/api/billing/active'
 */
getActiveBilling.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getActiveBilling.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\BillingController::getActiveBilling
 * @see app/Http/Controllers/Api/BillingController.php:185
 * @route '/api/billing/active'
 */
getActiveBilling.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getActiveBilling.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\BillingController::getActiveBilling
 * @see app/Http/Controllers/Api/BillingController.php:185
 * @route '/api/billing/active'
 */
    const getActiveBillingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getActiveBilling.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\BillingController::getActiveBilling
 * @see app/Http/Controllers/Api/BillingController.php:185
 * @route '/api/billing/active'
 */
        getActiveBillingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getActiveBilling.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\BillingController::getActiveBilling
 * @see app/Http/Controllers/Api/BillingController.php:185
 * @route '/api/billing/active'
 */
        getActiveBillingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getActiveBilling.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getActiveBilling.form = getActiveBillingForm
/**
* @see \App\Http\Controllers\Api\BillingController::checkExpiredTimedBillings
 * @see app/Http/Controllers/Api/BillingController.php:246
 * @route '/api/billing/check-expired'
 */
export const checkExpiredTimedBillings = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkExpiredTimedBillings.url(options),
    method: 'post',
})

checkExpiredTimedBillings.definition = {
    methods: ["post"],
    url: '/api/billing/check-expired',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\BillingController::checkExpiredTimedBillings
 * @see app/Http/Controllers/Api/BillingController.php:246
 * @route '/api/billing/check-expired'
 */
checkExpiredTimedBillings.url = (options?: RouteQueryOptions) => {
    return checkExpiredTimedBillings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BillingController::checkExpiredTimedBillings
 * @see app/Http/Controllers/Api/BillingController.php:246
 * @route '/api/billing/check-expired'
 */
checkExpiredTimedBillings.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkExpiredTimedBillings.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\BillingController::checkExpiredTimedBillings
 * @see app/Http/Controllers/Api/BillingController.php:246
 * @route '/api/billing/check-expired'
 */
    const checkExpiredTimedBillingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkExpiredTimedBillings.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\BillingController::checkExpiredTimedBillings
 * @see app/Http/Controllers/Api/BillingController.php:246
 * @route '/api/billing/check-expired'
 */
        checkExpiredTimedBillingsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkExpiredTimedBillings.url(options),
            method: 'post',
        })
    
    checkExpiredTimedBillings.form = checkExpiredTimedBillingsForm
const BillingController = { start, stop, getActiveBilling, checkExpiredTimedBillings }

export default BillingController